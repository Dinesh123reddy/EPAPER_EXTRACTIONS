# EXTRACTION > TRAIN DATASET-7
https://universe.roboflow.com/koni-9lsug/extraction-kzuf3

Provided by a Roboflow user
License: Public Domain

